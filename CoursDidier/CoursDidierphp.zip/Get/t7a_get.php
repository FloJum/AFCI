<?php

$nom = $_GET['nom'];
$ville = $_GET['ville'];

echo "hello. je m'appelle " . $nom . " et je vis à " . $ville;

var_dump($_get);