<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Test menu</title>
</head>
<body>
    <div>
        <?php
        include_once "t6_include.inc.php";
        ?>
    </div>
    <div>
        <h1>Bienvenu sur notre site</h1>
        <p style="color:blue">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, odio?<br>
            Quasi aspernatur nostrum amet voluptas omnis dolorum beatae fuga unde!<br>
            Debitis ipsum molestias architecto at voluptatem saepe incidunt, nulla mollitia!<br>
            Delectus voluptates aspernatur debitis voluptatum assumenda? Suscipit ratione praesentium sed<br>.
            A ad eos minus earum aliquid provident cum asperiores neque.<br>
            Quae vel ratione id facilis a eaque cupiditate nihil aperiam.<br>
            Nesciunt iusto ipsa quo adipisci ullam aliquid maiores assumenda qui!<br>
            Libero id soluta architecto nobis eos rerum molestias facere doloremque!<br>
        </p>
    </div>
</body>
</html>